var searchData=
[
  ['cadena',['cadena',['../struct_text_1_1_paraula.html#a299eb7b1d37b23168607145a8fa4208f',1,'Text::Paraula']]],
  ['contingut',['contingut',['../class_cita.html#a7f21bff7df1ce0654bb9b0e59726964b',1,'Cita']]]
];
