var searchData=
[
  ['atriat',['atriat',['../class_autor.html#ab4d03062565a3edf54bb606f1efa3f9d',1,'Autor']]],
  ['aut_5ftriat',['aut_triat',['../class_cjt__autors.html#abeba698925a25da2df41bf6a1226a41c',1,'Cjt_autors']]],
  ['autor',['autor',['../class_autor.html#ada30db41b077ab598ef7938f45f528cd',1,'Autor::autor()'],['../class_text.html#ad8f978ad7d2735c371990cce7bdc0d8f',1,'Text::autor()']]]
];
