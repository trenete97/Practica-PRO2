var searchData=
[
  ['iguals',['iguals',['../class_frase.html#a1235dc33276f1465912473ae094c5089',1,'Frase']]]
];
