var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mirar_5finicials',['mirar_inicials',['../class_cjt__autors.html#a4bea9f614960e81ae59c31df7dff876b',1,'Cjt_autors']]]
];
