var searchData=
[
  ['frases',['frases',['../class_text.html#ac538d584eec7934447a40aaa044a83d7',1,'Text']]],
  ['freq',['freq',['../struct_text_1_1_paraula.html#aff0eb74beabf07215768be9fda29083a',1,'Text::Paraula']]]
];
