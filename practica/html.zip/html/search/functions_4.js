var searchData=
[
  ['frase',['Frase',['../class_frase.html#a6af6ccf07cac65950917bc81f5e03c95',1,'Frase']]]
];
