var searchData=
[
  ['titol',['titol',['../class_cita.html#ae48282a8dd494783a60af6da42a057e5',1,'Cita::titol()'],['../class_text.html#abebeee870d4c29258cd1641b0e5f0947',1,'Text::titol()']]],
  ['ttriat',['ttriat',['../class_cjt__autors.html#a5a90e49d7ab4f6ebf292503a2bde3a4a',1,'Cjt_autors']]],
  ['txt_5ftriat',['txt_triat',['../class_autor.html#acbfb3577a3d178d692ae4defe598822f',1,'Autor']]]
];
