var searchData=
[
  ['buscar_5fpar',['buscar_par',['../class_cjt__autors.html#ae0fda0b32aecd009824c6372dfa79375',1,'Cjt_autors::buscar_par()'],['../class_text.html#a23499ae8402e8113e73ee01d2fcadf4a',1,'Text::buscar_par()']]],
  ['buscar_5fparaula',['buscar_paraula',['../class_frase.html#a6518e7f446580778965ceb03d7e01cd5',1,'Frase::buscar_paraula()'],['../class_text.html#a8a48d44a2204909a1a93534fa6b8290f',1,'Text::buscar_paraula()']]],
  ['buscar_5fseq',['buscar_seq',['../class_frase.html#aa7113b35d60f95cf0870aa5c6a907d92',1,'Frase::buscar_seq()'],['../class_text.html#aa29f26fc8d40de5380a722f3b31b16e9',1,'Text::buscar_seq()']]]
];
