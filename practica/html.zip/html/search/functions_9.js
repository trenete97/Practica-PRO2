var searchData=
[
  ['taula_5ffreq',['taula_freq',['../class_text.html#a695ffac7f15b19be00dae01d73bd8726',1,'Text']]],
  ['text',['Text',['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text']]],
  ['titols',['titols',['../class_autor.html#aa38e4f188593df38d0a69f142eb45873',1,'Autor']]],
  ['treu_5fespais',['treu_espais',['../class_text.html#ae331ba58e85330115415a40df6f8772e',1,'Text']]],
  ['tria_5ftext',['tria_text',['../class_autor.html#a858f4427e96bbab052f93869f29fbe0f',1,'Autor']]],
  ['triar_5ftxt',['triar_txt',['../class_cjt__autors.html#afb31f8cec6360d282c8a97f1b854106f',1,'Cjt_autors']]],
  ['txt_5ftriat',['txt_triat',['../class_cjt__autors.html#a470beb294014a9eb1b1c64711057c3e6',1,'Cjt_autors']]]
];
