var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['map_5fautor',['map_autor',['../class_cjt__autors.html#a776ae202d0fb912f91007d97b464ce27',1,'Cjt_autors']]],
  ['map_5fcita',['map_cita',['../class_autor.html#a3f6d58d3e1917adea93025efa47e26fd',1,'Autor']]],
  ['map_5fref',['map_ref',['../class_cjt__autors.html#a9efa3f16fe0193a4fcff278d6221bcbc',1,'Cjt_autors']]],
  ['map_5ftext',['map_text',['../class_autor.html#ab7666fb6296e3242c723760b0fe373d5',1,'Autor']]],
  ['mirar_5finicials',['mirar_inicials',['../class_cjt__autors.html#a4bea9f614960e81ae59c31df7dff876b',1,'Cjt_autors']]]
];
