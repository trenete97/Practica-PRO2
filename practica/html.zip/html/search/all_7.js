var searchData=
[
  ['num_5ffrases',['num_frases',['../class_autor.html#ae1f3d221d84a859642af248fa4c06dc7',1,'Autor::num_frases()'],['../class_text.html#a6bc225a62154872b67b5147d88047000',1,'Text::num_frases()']]],
  ['num_5fparaules',['num_paraules',['../class_autor.html#a71ed1dc626d31607b5a4655da66db48b',1,'Autor::num_paraules()'],['../class_text.html#a767fa4f48f28e4b91ed8c7dfc0395ce9',1,'Text::num_paraules()']]],
  ['num_5ftextos',['num_textos',['../class_autor.html#a568f90a1dd98f72e9253aaaf3f2c8e1a',1,'Autor']]]
];
