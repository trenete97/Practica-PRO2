var searchData=
[
  ['frase',['Frase',['../class_frase.html',1,'Frase'],['../class_frase.html#a6af6ccf07cac65950917bc81f5e03c95',1,'Frase::Frase()']]],
  ['frase_2ecc',['Frase.cc',['../_frase_8cc.html',1,'']]],
  ['frase_2ehh',['Frase.hh',['../_frase_8hh.html',1,'']]],
  ['frases',['frases',['../class_text.html#ac538d584eec7934447a40aaa044a83d7',1,'Text']]],
  ['freq',['freq',['../struct_text_1_1_paraula.html#aff0eb74beabf07215768be9fda29083a',1,'Text::Paraula']]]
];
