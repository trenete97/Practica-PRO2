var searchData=
[
  ['substituir_5fparaula',['substituir_paraula',['../class_autor.html#ad34412e8f625e039124b3e2961d68697',1,'Autor::substituir_paraula()'],['../class_cjt__autors.html#a29554d09e24a59e6365c19f122d09c2d',1,'Cjt_autors::substituir_paraula()'],['../class_frase.html#a702b4e6b6f10dd839b29087f80876631',1,'Frase::substituir_paraula()'],['../class_text.html#ad22e0cc137660d1dad93439a528ecde7',1,'Text::substituir_paraula()']]]
];
