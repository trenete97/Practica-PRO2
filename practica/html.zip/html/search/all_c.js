var searchData=
[
  ['taula_5ffreq',['taula_freq',['../class_text.html#a695ffac7f15b19be00dae01d73bd8726',1,'Text']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text::Text()']]],
  ['text_2ecc',['Text.cc',['../_text_8cc.html',1,'']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]],
  ['titol',['titol',['../class_cita.html#ae48282a8dd494783a60af6da42a057e5',1,'Cita::titol()'],['../class_text.html#abebeee870d4c29258cd1641b0e5f0947',1,'Text::titol()']]],
  ['titols',['titols',['../class_autor.html#aa38e4f188593df38d0a69f142eb45873',1,'Autor']]],
  ['treu_5fespais',['treu_espais',['../class_text.html#ae331ba58e85330115415a40df6f8772e',1,'Text']]],
  ['tria_5ftext',['tria_text',['../class_autor.html#a858f4427e96bbab052f93869f29fbe0f',1,'Autor']]],
  ['triar_5ftxt',['triar_txt',['../class_cjt__autors.html#afb31f8cec6360d282c8a97f1b854106f',1,'Cjt_autors']]],
  ['ttriat',['ttriat',['../class_cjt__autors.html#a5a90e49d7ab4f6ebf292503a2bde3a4a',1,'Cjt_autors']]],
  ['txt_5ftriat',['txt_triat',['../class_autor.html#acbfb3577a3d178d692ae4defe598822f',1,'Autor::txt_triat()'],['../class_cjt__autors.html#a470beb294014a9eb1b1c64711057c3e6',1,'Cjt_autors::txt_triat()']]]
];
