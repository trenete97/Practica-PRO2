var searchData=
[
  ['paraula',['Paraula',['../struct_text_1_1_paraula.html',1,'Text']]],
  ['paraules',['paraules',['../class_frase.html#a8daf9a22ec0753f340bf99785d1abc76',1,'Frase::paraules()'],['../class_text.html#ab8b954e38ab18aaa52fe83f97cf62857',1,'Text::paraules()']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
