var searchData=
[
  ['afegir_5faut',['afegir_aut',['../class_cjt__autors.html#a1b1d90ac076085d658af82dd04f212e4',1,'Cjt_autors']]],
  ['afegir_5fcita',['afegir_cita',['../class_autor.html#a57f04406dec030e67751547f80510a75',1,'Autor::afegir_cita()'],['../class_cjt__autors.html#a95fcd1b1321768353075f04eb5354232',1,'Cjt_autors::afegir_cita()']]],
  ['afegir_5fparaula',['afegir_paraula',['../class_frase.html#a63e30696c6c03247d6100cd08d886f93',1,'Frase']]],
  ['afegir_5fref',['afegir_ref',['../class_cjt__autors.html#ac16ec8d7e6676e1b2663948bed18a6df',1,'Cjt_autors']]],
  ['afegir_5ftxt',['afegir_txt',['../class_autor.html#a6f3498284d67548537add26c5482c3eb',1,'Autor']]],
  ['analitzar_5fexp',['analitzar_exp',['../class_frase.html#a100b3afb9ef2377001f0f5402f58b06c',1,'Frase']]],
  ['autor',['Autor',['../class_autor.html#a28111338918ed4358ca4adc2cc694b23',1,'Autor::Autor()'],['../class_autor.html#a4d808a930792eec0ede6bd2610e6f715',1,'Autor::Autor(string n)']]],
  ['autor_5ftriat',['autor_triat',['../class_autor.html#a5e740092b2d01dad72a50daea07ff961',1,'Autor']]],
  ['autors',['autors',['../class_cjt__autors.html#aad9025aab60544bccb2d53b34078b530',1,'Cjt_autors']]]
];
