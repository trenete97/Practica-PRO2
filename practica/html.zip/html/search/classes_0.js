var searchData=
[
  ['autor',['Autor',['../class_autor.html',1,'']]]
];
