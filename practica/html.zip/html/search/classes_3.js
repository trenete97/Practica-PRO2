var searchData=
[
  ['paraula',['Paraula',['../struct_text_1_1_paraula.html',1,'Text']]]
];
