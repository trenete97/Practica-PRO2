var searchData=
[
  ['omplir_5fcita',['omplir_cita',['../class_cita.html#ae1e04d64a1888b4cdfbd75bd00424271',1,'Cita']]],
  ['omplir_5ftext',['omplir_text',['../class_text.html#aad770703049ad0ea05b7d3fadfcf0b38',1,'Text']]],
  ['ordre',['ordre',['../class_text.html#a724c09270bf9b09841865321dc5ab8af',1,'Text']]]
];
