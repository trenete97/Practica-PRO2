var searchData=
[
  ['text_2ecc',['Text.cc',['../_text_8cc.html',1,'']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]]
];
