var searchData=
[
  ['eliminar_5fcita',['eliminar_cita',['../class_autor.html#a3f32e542c8292c6eabdd66a08cf38c2a',1,'Autor::eliminar_cita()'],['../class_cjt__autors.html#a75334d55288fde0fc609f49814e2da70',1,'Cjt_autors::eliminar_cita()']]],
  ['eliminar_5ftxt',['eliminar_txt',['../class_autor.html#ab4e09018ad4c66ab9f24a1fb36911eef',1,'Autor::eliminar_txt()'],['../class_cjt__autors.html#a589ebc438bb0057204f0da05d776145d',1,'Cjt_autors::eliminar_txt()']]],
  ['escriu_5fcontingut',['escriu_contingut',['../class_cita.html#a072ea73451c19e12d612dde669f4e4a1',1,'Cita']]],
  ['escriu_5ffrase',['escriu_frase',['../class_frase.html#a353bca5dfa35829c4ae83e924bc059d9',1,'Frase']]],
  ['escriu_5ffrases',['escriu_frases',['../class_text.html#a1655e23d77d89133110dbe8507b5cfe3',1,'Text']]],
  ['escriure_5fautor_5ft',['escriure_autor_t',['../class_autor.html#a85a55b0e8d5b0128c2f49fd7d05ada62',1,'Autor']]],
  ['escriure_5ftextos',['escriure_textos',['../class_cjt__autors.html#a2b3a3d9ff89b1884918521f174fe8be6',1,'Cjt_autors']]],
  ['existeix_5fcita',['existeix_cita',['../class_autor.html#ab4ab7f7b2f84e9c72e8ce578b3da3223',1,'Autor']]],
  ['exp_5ffrases',['exp_frases',['../class_cjt__autors.html#a5b45388f15e437140c51d6524e8549cc',1,'Cjt_autors::exp_frases()'],['../class_text.html#a6fb8477a5b319691f0d2058273c8795d',1,'Text::exp_frases()']]]
];
